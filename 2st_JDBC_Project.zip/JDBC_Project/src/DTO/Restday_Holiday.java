package DTO;

import lombok.Data;

@Data
public class Restday_Holiday {
	private String ename;
	private int restday;
}


