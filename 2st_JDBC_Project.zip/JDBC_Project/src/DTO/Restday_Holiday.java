package DTO;

import lombok.Data;

@Data
public class Restday_Holiday {
	private int empno;
	private int restday;
}


